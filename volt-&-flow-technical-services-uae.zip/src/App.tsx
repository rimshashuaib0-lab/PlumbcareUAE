import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ServicesSection from './components/ServicesSection';
import AboutSection from './components/AboutSection';
import ProcessSection from './components/ProcessSection';
import USPSection from './components/USPSection';
import FAQSection from './components/FAQSection';
import TestimonialsSection from './components/TestimonialsSection';
import CTABanner from './components/CTABanner';
import Footer from './components/Footer';

import BookingModal from './components/BookingModal';
import QuoteModal from './components/QuoteModal';
import ServiceDetailModal from './components/ServiceDetailModal';
import VideoModal from './components/VideoModal';
import AskQuestionModal from './components/AskQuestionModal';
import FloatingEmergencyButton from './components/FloatingEmergencyButton';

import { ServiceItem } from './types';

export default function App() {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [askModalOpen, setAskModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [preselectedBookingServiceId, setPreselectedBookingServiceId] = useState<string | undefined>();

  const handleOpenBooking = (serviceId?: string) => {
    setPreselectedBookingServiceId(serviceId);
    setBookingModalOpen(true);
  };

  const handleSelectService = (service: ServiceItem) => {
    setSelectedService(service);
  };

  const handleBookFromServiceDetail = (serviceId: string) => {
    setSelectedService(null);
    handleOpenBooking(serviceId);
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-900">
      {/* Navigation */}
      <Navbar
        onOpenBooking={() => handleOpenBooking()}
        onOpenQuote={() => setQuoteModalOpen(true)}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onOpenBooking={() => handleOpenBooking()}
          onOpenVideo={() => setVideoModalOpen(true)}
        />

        {/* Services Section */}
        <ServicesSection
          onSelectService={handleSelectService}
          onOpenBookingWithService={(serviceId) => handleOpenBooking(serviceId)}
        />

        {/* About & Trust Section (includes 4-Stat Block) */}
        <AboutSection
          onOpenBooking={() => handleOpenBooking()}
          onOpenQuote={() => setQuoteModalOpen(true)}
        />

        {/* Process Section */}
        <ProcessSection onOpenBooking={() => handleOpenBooking()} />

        {/* Dark Difference / USP Banner Section */}
        <USPSection onOpenBooking={() => handleOpenBooking()} />

        {/* FAQ Section */}
        <FAQSection
          onOpenBooking={() => handleOpenBooking()}
          onOpenAskQuestion={() => setAskModalOpen(true)}
        />

        {/* Testimonials Carousel Section */}
        <TestimonialsSection />

        {/* Bottom CTA Banner */}
        <CTABanner onOpenBooking={() => handleOpenBooking()} />
      </main>

      {/* Footer */}
      <Footer
        onOpenBooking={() => handleOpenBooking()}
        onOpenQuote={() => setQuoteModalOpen(true)}
      />

      {/* Floating Emergency & Quick Booking Actions */}
      <FloatingEmergencyButton onOpenBooking={() => handleOpenBooking()} />

      {/* Interactive Modals */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        preselectedServiceId={preselectedBookingServiceId}
      />

      <QuoteModal
        isOpen={quoteModalOpen}
        onClose={() => setQuoteModalOpen(false)}
        onProceedToBook={(serviceId) => handleOpenBooking(serviceId)}
      />

      <ServiceDetailModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onBookService={handleBookFromServiceDetail}
      />

      <VideoModal
        isOpen={videoModalOpen}
        onClose={() => setVideoModalOpen(false)}
        onOpenBooking={() => handleOpenBooking()}
      />

      <AskQuestionModal
        isOpen={askModalOpen}
        onClose={() => setAskModalOpen(false)}
      />
    </div>
  );
}

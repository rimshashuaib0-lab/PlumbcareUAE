import { CheckCircle2, ShieldCheck, Users, Award, Clock, ArrowRight } from 'lucide-react';
import { IMAGES, STATS } from '../data/content';

interface AboutSectionProps {
  onOpenBooking: () => void;
  onOpenQuote: () => void;
}

export default function AboutSection({ onOpenBooking, onOpenQuote }: AboutSectionProps) {
  const getStatIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-[#0A4DA2]" />;
      case 'Users':
        return <Users className="w-6 h-6 text-[#0A4DA2]" />;
      case 'CheckCircle2':
        return <Award className="w-6 h-6 text-[#0A4DA2]" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-[#0A4DA2]" />;
      default:
        return <Award className="w-6 h-6 text-[#0A4DA2]" />;
    }
  };

  const checkmarks = [
    {
      title: 'DEWA, SEWA & Civil Defense Accreditation',
      desc: 'All electro-mechanical works are executed in strict alignment with UAE regulatory bodies and British Standard BS 7671.',
    },
    {
      title: 'Binding Contractual Quotations',
      desc: 'Complete fiscal clarity with fully itemized, fixed AED scopes of work authorized prior to physical intervention.',
    },
    {
      title: 'Site Preservation & Cleanliness Standards',
      desc: 'Engineers wear protective shoe barriers, install surface drop membranes, and restore the operational environment completely.',
    },
    {
      title: 'Contractual 12-Month Stamped Warranty',
      desc: 'Comprehensive legal warranty documentation covering both certified labor and manufacturer-backed replacement components.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Two-Column About Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Photo of Senior Engineer */}
          <div className="lg:col-span-5 relative flex justify-center">
            {/* Subtle blue background shape */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-gradient-to-tr from-[#003C7E]/15 to-[#0A4DA2]/25 -z-10 blur-xl" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 sm:w-80 sm:h-80 rounded-full border-2 border-[#0A4DA2]/20 -z-10 animate-pulse-subtle" />

            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white max-w-sm sm:max-w-md bg-slate-100">
              <img
                src={IMAGES.aboutTechnician}
                alt="PlumbCare UAE Senior Master Engineer"
                className="w-full h-auto object-cover object-center max-h-[520px]"
                referrerPolicy="no-referrer"
              />

              {/* Floating Credentials Card on Photo */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-slate-100 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#003C7E] to-[#0A4DA2] text-amber-400 flex items-center justify-center shrink-0 font-black text-lg">
                  15+
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 leading-tight">
                    Years of Engineering Practice
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Managing critical MEP assets across the UAE
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Copy & Checklist */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider">
              <span>Your Trusted Plumbing Partner</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Proven Engineering Integrity &amp; Technical Mastery Across the UAE
            </h2>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              Established in Dubai, PlumbCare UAE operates as an accredited plumbing and electro-mechanical contracting firm delivering institutional-grade technical management. We eliminate recurring infrastructure failures and premature asset degradation through rigorous diagnostic methodologies and licensed master engineers.
            </p>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              From subterranean acoustic leak pinpointing in prime residential communities like Emirates Hills and Palm Jumeirah to complex three-phase load redistribution and commercial hydraulic network restoration, our teams maintain unmatched standards of engineering precision, safety, and accountability.
            </p>

            {/* 4 Checkmark Bullet Points (2x2 Grid) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {checkmarks.map((item, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                    <p className="text-xs text-slate-600 mt-1 leading-snug">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Structured Action Buttons */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md shadow-amber-500/20 transition-all duration-200 cursor-pointer"
              >
                <span>Mobilize Technical Team</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onOpenQuote}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm text-[#0A4DA2] bg-blue-50 hover:bg-blue-100 transition-colors cursor-pointer"
              >
                <span>Request Scope &amp; Tariffs</span>
              </button>
            </div>
          </div>
        </div>

        {/* Separate Stat Card Block (Light Background) */}
        <div className="mt-20 p-8 sm:p-10 rounded-3xl bg-[#F5F7FA] border border-slate-200/80 shadow-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {STATS.map((stat, idx) => (
              <div
                key={idx}
                className="flex flex-col items-center sm:items-start text-center sm:text-left space-y-2 p-2"
              >
                <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-slate-200/80 flex items-center justify-center mb-1">
                  {getStatIcon(stat.iconName)}
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold text-[#003C7E] tracking-tight tabular-nums font-mono">
                  {stat.value}
                </div>
                <div className="text-base font-bold text-slate-900 leading-snug">
                  {stat.label}
                </div>
                <div className="text-xs text-slate-500 leading-relaxed">
                  {stat.subtext}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

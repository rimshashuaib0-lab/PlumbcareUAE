import { useState } from 'react';
import { X, Send, CheckCircle2, MessageSquare, Phone } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface AskQuestionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AskQuestionModal({ isOpen, onClose }: AskQuestionModalProps) {
  const [question, setQuestion] = useState('');
  const [contact, setContact] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        <div className="bg-gradient-to-r from-[#003C7E] to-[#0A4DA2] text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold tracking-tight">
                Engineering Consultation Desk
              </h3>
              <p className="text-xs text-blue-100 mt-0.5">
                PlumbCare UAE · Senior Master Plumbing Directorate
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold text-slate-900">
              Technical Inquiry Transmitted
            </h4>
            <p className="text-sm text-slate-600">
              A licensed senior MEP engineer has received your parameters and will provide a formal advisory response within 15 minutes.
            </p>
            <button
              type="button"
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="mt-4 px-6 py-2.5 rounded-xl font-bold text-sm bg-slate-900 text-white hover:bg-slate-800 transition-colors"
            >
              Acknowledge &amp; Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Technical Query or System Specification
              </label>
              <textarea
                required
                rows={3}
                placeholder="Detail technical specifications: e.g. Dynamic water pressure requirements for multi-shower configurations in private villa, thermal switchgear sizing, or solar cylinder glycol loop..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Direct Contact Telephone / WhatsApp
              </label>
              <input
                type="text"
                required
                placeholder="+971 50 123 4567"
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
              />
            </div>

            <div className="p-3 rounded-xl bg-blue-50 border border-blue-100 flex items-center gap-2 text-xs text-blue-900">
              <Phone className="w-4 h-4 text-[#0A4DA2] shrink-0" />
              <span>For critical emergencies requiring under 30-min mobilization, dial {COMPANY_INFO.hotlineDisplay}.</span>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Transmit Query to Lead Engineer</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

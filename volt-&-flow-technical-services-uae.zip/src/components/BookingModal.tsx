import { useState } from 'react';
import { X, Calendar, Clock, Phone, User, Mail, AlertTriangle, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { SERVICES, SERVICE_AREAS, COMPANY_INFO } from '../data/content';
import { BookingFormData } from '../types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedServiceId?: string;
}

export default function BookingModal({ isOpen, onClose, preselectedServiceId }: BookingModalProps) {
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    phone: '',
    email: '',
    serviceId: preselectedServiceId || SERVICES[0].id,
    emirate: 'Dubai',
    area: SERVICE_AREAS[0],
    urgency: 'emergency_30min',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTime: 'Morning Window (08:00 - 12:00)',
    notes: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bookingRef, setBookingRef] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const randomRef = `PC-${Math.floor(10000 + Math.random() * 90000)}`;
      setBookingRef(randomRef);
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#003C7E] to-[#0A4DA2] text-white p-6 sm:p-7 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold tracking-tight">
                Schedule Engineering Inspection &amp; Dispatch
              </h3>
              <p className="text-xs text-blue-100 mt-0.5">
                PlumbCare UAE · Your Trusted Plumbing &amp; MEP Partner
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        {isSubmitted ? (
          <div className="p-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Dispatch Registration Confirmed
              </span>
              <h4 className="text-2xl font-black text-slate-900">
                Engineering Mobilization Authorized
              </h4>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Thank you, <strong className="text-slate-900">{formData.fullName}</strong>. Your deployment dossier has been submitted to the PlumbCare UAE central operations control desk in Dubai.
              </p>
            </div>

            {/* Confirmation Dossier */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 max-w-md mx-auto text-left space-y-2.5 text-xs sm:text-sm">
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">Dispatch Reference:</span>
                <span className="font-mono font-bold text-[#0A4DA2]">{bookingRef}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">Specified Discipline:</span>
                <span className="font-semibold text-slate-800">
                  {SERVICES.find((s) => s.id === formData.serviceId)?.title}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-slate-200">
                <span className="text-slate-500 font-medium">Premises Location:</span>
                <span className="font-semibold text-slate-800">
                  {formData.area}, {formData.emirate}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Deployment Priority:</span>
                <span className="font-bold text-amber-700">
                  {formData.urgency === 'emergency_30min'
                    ? '⚡ Tier 1: Critical Emergency (30-Min Rapid Mobilization)'
                    : formData.urgency === 'today'
                    ? 'Tier 2: Same-Day Scheduled Priority'
                    : 'Tier 3: Planned Engineering Survey'}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-blue-50 border border-blue-100 max-w-md mx-auto text-xs text-blue-900 flex items-center gap-3">
              <Phone className="w-4 h-4 text-[#0A4DA2] shrink-0" />
              <span>
                To coordinate directly with the lead duty engineer, telephone{' '}
                <a href={`tel:${COMPANY_INFO.hotline}`} className="font-bold underline">
                  {COMPANY_INFO.hotlineDisplay}
                </a>
              </span>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="px-8 py-3 rounded-xl font-bold text-sm bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Acknowledge &amp; Return to Overview
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-5">
            {/* Priority Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                Operational Priority Tier
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, urgency: 'emergency_30min' })}
                  className={`p-3 rounded-xl text-left border text-xs font-bold transition-all cursor-pointer ${
                    formData.urgency === 'emergency_30min'
                      ? 'bg-amber-50 border-amber-500 text-amber-950 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-amber-700 mb-0.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Tier 1: Critical (30 Min)</span>
                  </div>
                  <p className="text-[11px] font-normal text-slate-500">
                    Pressurized pipe breach, electrical flash, power loss
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, urgency: 'today' })}
                  className={`p-3 rounded-xl text-left border text-xs font-bold transition-all cursor-pointer ${
                    formData.urgency === 'today'
                      ? 'bg-blue-50 border-blue-600 text-blue-950 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-[#0A4DA2] mb-0.5">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Tier 2: Same-Day (2-4 Hrs)</span>
                  </div>
                  <p className="text-[11px] font-normal text-slate-500">
                    Thermal boiler failure, recurring breaker trip
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, urgency: 'scheduled' })}
                  className={`p-3 rounded-xl text-left border text-xs font-bold transition-all cursor-pointer ${
                    formData.urgency === 'scheduled'
                      ? 'bg-slate-100 border-slate-700 text-slate-900 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-slate-700 mb-0.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Tier 3: Planned Survey</span>
                  </div>
                  <p className="text-[11px] font-normal text-slate-500">
                    Comprehensive rewiring, switchgear audit, EVSE
                  </p>
                </button>
              </div>
            </div>

            {/* Service & Location */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Required Engineering Discipline
                </label>
                <select
                  value={formData.serviceId}
                  onChange={(e) => setFormData({ ...formData, serviceId: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  required
                >
                  {SERVICES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.title} (Tariff from AED {s.startingPriceAED})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Emirate &amp; Operational District
                </label>
                <div className="flex gap-2">
                  <select
                    value={formData.emirate}
                    onChange={(e) => setFormData({ ...formData, emirate: e.target.value })}
                    className="w-1/3 px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  >
                    <option value="Dubai">Dubai</option>
                    <option value="Abu Dhabi">Abu Dhabi</option>
                    <option value="Sharjah">Sharjah</option>
                    <option value="Ajman">Ajman</option>
                  </select>

                  <select
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    className="w-2/3 px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  >
                    {SERVICE_AREAS.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Contact Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Authorized Contact Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eng. Tariq Al-Mansouri"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  UAE Mobile Telephone Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    placeholder="+971 50 123 4567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  />
                </div>
              </div>
            </div>

            {/* Email and Date/Time */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Official Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="contact@enterprise.ae"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Requested Date
                </label>
                <input
                  type="date"
                  value={formData.preferredDate}
                  onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Time Window
                </label>
                <select
                  value={formData.preferredTime}
                  onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                >
                  <option value="Morning Window (08:00 - 12:00)">Morning Window (08:00 - 12:00)</option>
                  <option value="Afternoon Window (12:00 - 16:00)">Afternoon Window (12:00 - 16:00)</option>
                  <option value="Evening Window (16:00 - 20:00)">Evening Window (16:00 - 20:00)</option>
                  <option value="Overnight Emergency Mobilization">Overnight Critical Window</option>
                </select>
              </div>
            </div>

            {/* Technical Symptoms */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Technical Symptoms &amp; Fault Description (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="Detail observable symptoms: e.g. Differential pressure drop, thermal discoloration on DB panel, RCD tripping under HVAC load..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
              />
            </div>

            {/* Compliance Guarantee Strip */}
            <div className="flex items-center gap-3 text-xs text-slate-500 pt-1">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Binding Contractual AED Tariffs
              </span>
              <span>•</span>
              <span>12-Month Performance Guarantee SLA</span>
            </div>

            {/* Submit Action */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 px-6 rounded-2xl font-bold text-base bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-lg shadow-amber-500/25 transition-all duration-200 active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span>Transmitting Dispatch Request...</span>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-slate-950" />
                    <span>Authorize &amp; Dispatch Engineering Unit</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

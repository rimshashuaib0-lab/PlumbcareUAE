import { PhoneCall, Calendar, Clock, ShieldCheck, ArrowRight } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface CTABannerProps {
  onOpenBooking: () => void;
}

export default function CTABanner({ onOpenBooking }: CTABannerProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-[#002D62] via-[#003C7E] to-[#0A4DA2] text-white py-16 lg:py-20">
      {/* Decorative Wave/Circuit Background Patterns */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 1000 1000" preserveAspectRatio="none">
          <path
            d="M0,300 C300,500 700,100 1000,400 L1000,1000 L0,1000 Z"
            fill="white"
          />
        </svg>
      </div>
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-amber-400/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center justify-between">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/10 border border-white/20 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5" />
              <span>Continuous 24-Hour Emergency Intervention Fleet</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              Require Urgent Technical Intervention or a Structured Site Survey?
            </h2>

            <p className="text-base sm:text-lg text-blue-100 max-w-xl leading-relaxed">
              Protect your infrastructure from structural water ingress and electrical failure. Our mobile master engineers are deployed across Dubai and Abu Dhabi.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2 text-xs sm:text-sm text-blue-200">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> DEWA Accredited Registry
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Binding Contractual Tariffs
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> 12-Month Performance SLA
              </span>
            </div>
          </div>

          {/* Right Action Column */}
          <div className="lg:col-span-5 flex flex-col sm:flex-row lg:flex-col xl:flex-row items-stretch sm:items-center lg:items-end xl:items-center justify-end gap-4">
            {/* Action Button */}
            <button
              type="button"
              onClick={onOpenBooking}
              className="inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl font-bold text-base bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-xl shadow-amber-500/30 transition-all duration-200 active:scale-98 cursor-pointer whitespace-nowrap"
            >
              <Calendar className="w-5 h-5 text-slate-950" />
              <span>Schedule Inspection</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>

            {/* Direct Phone Call Card */}
            <a
              href={`tel:${COMPANY_INFO.hotline}`}
              className="group inline-flex items-center justify-center gap-3.5 px-6 py-4 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/20 transition-all text-white backdrop-blur-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <PhoneCall className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-[10px] uppercase font-bold text-amber-300 tracking-wider block">
                  Technical Dispatch Desk
                </span>
                <span className="text-base font-extrabold text-white tracking-wide">
                  {COMPANY_INFO.hotlineDisplay}
                </span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

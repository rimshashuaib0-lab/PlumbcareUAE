import { useState } from 'react';
import { Plus, Minus, HelpCircle, FileText } from 'lucide-react';
import { FAQS, IMAGES } from '../data/content';

interface FAQSectionProps {
  onOpenBooking: () => void;
  onOpenAskQuestion: () => void;
}

export default function FAQSection({ onOpenBooking, onOpenAskQuestion }: FAQSectionProps) {
  const [openId, setOpenId] = useState<string>('faq-1');

  const toggleFAQ = (id: string) => {
    setOpenId(openId === id ? '' : id);
  };

  return (
    <section id="faq" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-start">
          {/* Left Column (Image + Heading + Subtext + Button) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-100 text-[#0A4DA2] text-xs font-bold uppercase tracking-wider">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Contractual &amp; Operational Governance</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Frequently Addressed Technical Inquiries
            </h2>

            <p className="text-base text-slate-600 leading-relaxed">
              Transparent, authoritative guidance regarding our rapid mobilization windows across Dubai, transparent AED rate schedules, DEWA engineering credentials, and contractual warranties.
            </p>

            {/* Left Image Display */}
            <div className="relative rounded-3xl overflow-hidden shadow-lg border-4 border-white bg-slate-100 aspect-4/3 sm:aspect-auto">
              <img
                src={IMAGES.faqInterior}
                alt="Al Shuaib architectural hydraulic installation in private Dubai villa"
                className="w-full h-auto object-cover max-h-[340px]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end p-5">
                <p className="text-xs font-semibold text-white/90">
                  Architectural MEP installation in high-capacity Dubai residential estate
                </p>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={onOpenAskQuestion}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Submit Technical Inquiry</span>
              </button>

              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm text-[#0A4DA2] bg-white border border-slate-200 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <span>Schedule Site Survey</span>
              </button>
            </div>
          </div>

          {/* Right Column: Accordion List */}
          <div className="lg:col-span-7 space-y-4">
            {FAQS.map((faq) => {
              const isOpen = openId === faq.id;
              return (
                <div
                  key={faq.id}
                  className={`rounded-2xl transition-all duration-200 border ${
                    isOpen
                      ? 'bg-white border-blue-200 shadow-md ring-1 ring-blue-500/10'
                      : 'bg-white/80 border-slate-200/80 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleFAQ(faq.id)}
                    className="w-full px-6 py-5 flex items-center justify-between text-left gap-4 focus:outline-none cursor-pointer"
                    aria-expanded={isOpen}
                  >
                    <span className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                      {faq.question}
                    </span>
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors duration-200 ${
                        isOpen
                          ? 'bg-[#0A4DA2] text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-6 pb-5 pt-1 text-sm sm:text-base text-slate-600 leading-relaxed border-t border-slate-100">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

import { PhoneCall, Calendar } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';

interface FloatingEmergencyButtonProps {
  onOpenBooking: () => void;
}

export default function FloatingEmergencyButton({ onOpenBooking }: FloatingEmergencyButtonProps) {
  return (
    <div className="fixed bottom-5 right-4 sm:right-6 z-40 flex flex-col items-end gap-2.5">
      {/* 24/7 Critical Hotline */}
      <a
        href={`tel:${COMPANY_INFO.hotline}`}
        className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-xl shadow-red-700/30 transition-all duration-200 active:scale-95"
        title="24/7 Critical Technical Dispatch"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
        <PhoneCall className="w-4 h-4" />
        <span className="text-xs font-black tracking-wide hidden sm:inline">
          Critical Hotline 24/7: {COMPANY_INFO.hotlineDisplay}
        </span>
        <span className="text-xs font-black tracking-wide sm:hidden">
          Critical Dispatch
        </span>
      </a>

      {/* Schedule Inspection Button */}
      <button
        type="button"
        onClick={onOpenBooking}
        className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-lg shadow-amber-500/25 text-xs font-bold transition-all duration-200 active:scale-95 cursor-pointer"
      >
        <Calendar className="w-3.5 h-3.5 text-slate-950" />
        <span>Schedule Survey</span>
      </button>
    </div>
  );
}

import { Phone, Mail, MapPin, Clock, ShieldCheck } from 'lucide-react';
import { COMPANY_INFO, SERVICES } from '../data/content';
import PlumbCareLogo from './PlumbCareLogo';

interface FooterProps {
  onOpenBooking: () => void;
  onOpenQuote: () => void;
}

export default function Footer({ onOpenBooking, onOpenQuote }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="contact" className="bg-[#0B1E3D] text-slate-300 pt-16 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 4-Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-14 border-b border-white/10">
          {/* Col 1: Corporate Entity (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10 inline-block">
              <PlumbCareLogo dark={true} />
            </div>

            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              PlumbCare UAE is your trusted plumbing and MEP technical partner across Dubai, Abu Dhabi, and the Northern Emirates. Providing DEWA-approved engineering, 24/7 rapid emergency dispatch, and comprehensive preventative maintenance for private villas and prime facilities.
            </p>

            <div className="space-y-1.5 text-xs text-slate-400 pt-1">
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{COMPANY_INFO.licenseNo}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{COMPANY_INFO.dewaApproved}</span>
              </div>
            </div>
          </div>

          {/* Col 2: Navigation Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Institutional Index
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <a href="#home" className="hover:text-amber-400 transition-colors">Overview</a>
              </li>
              <li>
                <a href="#about" className="hover:text-amber-400 transition-colors">Corporate Profile</a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-400 transition-colors">Capabilities</a>
              </li>
              <li>
                <a href="#process" className="hover:text-amber-400 transition-colors">Execution Model</a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-amber-400 transition-colors">Quality Standards</a>
              </li>
              <li>
                <a href="#faq" className="hover:text-amber-400 transition-colors">Technical FAQ</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-amber-400 transition-colors">Client Dossier</a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenQuote}
                  className="hover:text-amber-400 transition-colors text-left cursor-pointer"
                >
                  Rate Card Estimator
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Core Disciplines (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Engineering Disciplines
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              {SERVICES.map((s) => (
                <li key={s.id}>
                  <a
                    href="#services"
                    className="hover:text-amber-400 transition-colors block truncate"
                    title={s.title}
                  >
                    {s.title}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="text-xs font-bold text-amber-400 hover:text-amber-300 underline transition-colors cursor-pointer"
                >
                  Schedule Engineering Survey →
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Corporate Contact (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Technical Dispatch Desk
            </h4>
            <div className="space-y-3 text-sm text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span className="text-xs leading-relaxed text-slate-400">
                  {COMPANY_INFO.address}
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a
                  href={`tel:${COMPANY_INFO.hotline}`}
                  className="text-sm font-bold text-white hover:text-amber-400 transition-colors"
                >
                  {COMPANY_INFO.hotlineDisplay}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a
                  href={`mailto:${COMPANY_INFO.email}`}
                  className="text-xs text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {COMPANY_INFO.email}
                </a>
              </div>

              <div className="flex items-start gap-2.5 pt-1">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-xs text-emerald-400 font-medium">
                  {COMPANY_INFO.operatingHours}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Legal & Regulatory Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-4">
          <p>© {currentYear} {COMPANY_INFO.name}. All rights reserved.</p>
          <div className="flex items-center gap-6 text-slate-400">
            <span>Dubai Municipality Licensed</span>
            <span>•</span>
            <span>DEWA Registered Contractor</span>
            <span>•</span>
            <a href="#home" className="hover:text-amber-400 transition-colors">Return to Top ↑</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

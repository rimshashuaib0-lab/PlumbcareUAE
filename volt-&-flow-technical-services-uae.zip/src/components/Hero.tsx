import { PhoneCall, Play, Clock, ShieldCheck, Banknote, Award, CheckCircle2, ChevronRight } from 'lucide-react';
import { COMPANY_INFO, IMAGES } from '../data/content';

interface HeroProps {
  onOpenBooking: () => void;
  onOpenVideo: () => void;
}

export default function Hero({ onOpenBooking, onOpenVideo }: HeroProps) {
  return (
    <section id="home" className="relative overflow-hidden bg-white pt-6 pb-16 lg:pt-12 lg:pb-24">
      {/* Ambient background visual balance */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-blue-100/40 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-amber-100/30 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute -bottom-10 left-10 w-72 h-72 bg-slate-100/70 rounded-full blur-2xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column (Corporate Presentation) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Accreditation Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 border border-slate-200 shadow-2xs">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-[#0084D6]">
                Your Trusted Plumbing Partner
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-xs font-semibold text-slate-600 hidden sm:inline">
                Dubai, Abu Dhabi &amp; Northern Emirates
              </span>
            </div>

            {/* Authoritative Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]">
              Precision Plumbing &amp; Electrical Engineering{' '}
              <span className="text-[#0084D6] block mt-1.5">Your Trusted Partner Across the UAE</span>
            </h1>

            {/* Executive Prose */}
            <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
              PlumbCare UAE delivers certified master plumbing, sub-surface acoustic leak diagnostics, drain hydro-jetting, and electro-mechanical infrastructure maintenance for prime residential estates, luxury villas, and commercial facilities.
            </p>

            {/* Structured CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-2xl font-bold text-base bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-lg shadow-amber-500/20 hover:shadow-xl hover:shadow-amber-500/30 transition-all duration-200 active:scale-98 cursor-pointer"
              >
                <span>Schedule Engineering Inspection</span>
                <ChevronRight className="w-4 h-4 text-slate-950" />
              </button>

              <button
                type="button"
                onClick={onOpenVideo}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl font-semibold text-base text-slate-700 bg-white hover:bg-slate-50 border-2 border-slate-200 hover:border-slate-300 transition-all duration-200 active:scale-98 shadow-sm cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-full bg-blue-50 text-[#0A4DA2] flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-4 h-4 fill-[#0A4DA2] ml-0.5" />
                </div>
                <span>Corporate Capability Profile</span>
              </button>
            </div>

            {/* Trust Badges Row */}
            <div className="pt-6 border-t border-slate-200">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0A4DA2] flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">24/7 Intervention</p>
                    <p className="text-[11px] text-slate-500 leading-tight">30-Min Rapid Response</p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">DEWA Accredited</p>
                    <p className="text-[11px] text-slate-500 leading-tight">License #TR-884920</p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <Banknote className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">Transparent Tariffs</p>
                    <p className="text-[11px] text-slate-500 leading-tight">Contractual AED Quotes</p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#0A4DA2] flex items-center justify-center shrink-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">Quality Assurance</p>
                    <p className="text-[11px] text-slate-500 leading-tight">12-Month Stamped SLA</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column (Hero Visual with Technical Overlays) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer boundary frame */}
              <div className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-[#003C7E]/20 to-amber-500/20 blur-lg -z-10" />

              {/* Main Photo */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-slate-100 aspect-4/3 sm:aspect-auto">
                <img
                  src={IMAGES.heroTechnician}
                  alt="PlumbCare UAE certified master plumbing and electrical engineer executing precision diagnostics"
                  className="w-full h-full object-cover object-center max-h-[500px]"
                  referrerPolicy="no-referrer"
                />

                {/* Corporate Credentials Card */}
                <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl shadow-lg border border-slate-200/60 flex items-center gap-2 text-xs font-bold text-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Licensed UAE MEP Engineers</span>
                </div>
              </div>

              {/* Floating Emergency Intervention Card (Bottom-Right) */}
              <div className="absolute -bottom-6 -right-2 sm:right-4 bg-gradient-to-r from-[#003C7E] to-[#0A4DA2] text-white p-4 sm:p-5 rounded-2xl shadow-xl shadow-blue-950/25 border border-white/10 max-w-[290px] sm:max-w-[310px]">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 shadow-md">
                    <PhoneCall className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold tracking-wider uppercase text-amber-300 block">
                      Critical Intervention Desk
                    </span>
                    <a
                      href={`tel:${COMPANY_INFO.hotline}`}
                      className="text-base sm:text-lg font-black text-white hover:text-amber-300 transition-colors block leading-tight mt-0.5"
                    >
                      {COMPANY_INFO.hotlineDisplay}
                    </a>
                  </div>
                </div>
                <div className="mt-2.5 pt-2 border-t border-white/15 flex items-center justify-between text-[11px] text-blue-100">
                  <span>Continuous 24/7 Readiness</span>
                  <span className="font-semibold text-amber-300">~30 Min Mobilization</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

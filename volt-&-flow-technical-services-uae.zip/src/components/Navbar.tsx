import { useState, useEffect } from 'react';
import { Phone, ArrowRight, Menu, X, Clock } from 'lucide-react';
import { COMPANY_INFO } from '../data/content';
import PlumbCareLogo from './PlumbCareLogo';

interface NavbarProps {
  onOpenBooking: () => void;
  onOpenQuote: () => void;
}

export default function Navbar({ onOpenBooking, onOpenQuote }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Overview', href: '#home' },
    { label: 'Corporate Profile', href: '#about' },
    { label: 'Capabilities', href: '#services' },
    { label: 'Execution Model', href: '#process' },
    { label: 'Standards', href: '#why-us' },
    { label: 'Technical FAQ', href: '#faq' },
    { label: 'Client Dossier', href: '#testimonials' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Engineering & Accreditation Notice Bar */}
      <div className="bg-[#0B1E3D] text-slate-300 text-xs py-2 px-4 border-b border-white/10 hidden md:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-medium text-amber-400">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              24/7 Rapid Emergency Response &amp; Engineering Dispatch
            </span>
            <span className="text-white/20">|</span>
            <span className="text-slate-300">
              {COMPANY_INFO.dewaApproved} · {COMPANY_INFO.licenseNo}
            </span>
          </div>

          <div className="flex items-center gap-5">
            <a
              href={`tel:${COMPANY_INFO.hotline}`}
              className="flex items-center gap-1.5 font-semibold text-white hover:text-amber-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>Hotline: {COMPANY_INFO.hotlineDisplay}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-md py-3 border-b border-slate-200/80'
            : 'bg-white py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo (Left) */}
            <a href="#home" className="flex items-center group py-0.5" title="PlumbCare UAE - Your Trusted Plumbing Partner">
              <PlumbCareLogo className="group-hover:opacity-95 transition-opacity" />
            </a>

            {/* Center Navigation Links */}
            <nav className="hidden lg:flex items-center gap-6 xl:gap-7 text-sm font-medium text-slate-600">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="relative py-1 text-slate-600 hover:text-[#0084D6] transition-colors duration-150 group"
                >
                  {link.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0084D6] transition-all duration-200 group-hover:w-full" />
                </a>
              ))}
            </nav>

            {/* Right Action Buttons */}
            <div className="hidden sm:flex items-center gap-3">
              <a
                href={`tel:${COMPANY_INFO.hotline}`}
                className="hidden xl:flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                title="Immediate Technical Consultation"
              >
                <Phone className="w-3.5 h-3.5 text-[#0A4DA2]" />
                <span>Hotline: {COMPANY_INFO.hotline}</span>
              </a>

              <button
                type="button"
                onClick={onOpenQuote}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md shadow-amber-500/20 hover:shadow-lg hover:shadow-amber-500/30 transition-all duration-200 active:scale-95 cursor-pointer"
              >
                <span>Request Quotation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Hamburger Toggle */}
            <div className="flex sm:hidden items-center gap-2">
              <button
                type="button"
                onClick={onOpenBooking}
                className="px-3 py-1.5 text-xs font-bold bg-amber-500 text-slate-950 rounded-lg shadow-sm"
              >
                Dispatch
              </button>

              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-700 hover:text-[#0A4DA2] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A4DA2]"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-slate-200 shadow-xl px-4 pt-3 pb-6 space-y-2 mt-2">
            <div className="p-3 mb-2 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-between text-xs">
              <span className="font-semibold text-[#0A4DA2] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" /> 24/7 Operations Desk Active
              </span>
              <a
                href={`tel:${COMPANY_INFO.hotline}`}
                className="font-bold text-[#003C7E] flex items-center gap-1"
              >
                <Phone className="w-3 h-3" /> Call Hotline
              </a>
            </div>

            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#0A4DA2] transition-colors"
              >
                {link.label}
              </a>
            ))}

            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenQuote();
                }}
                className="w-full py-3 px-4 rounded-xl font-bold text-center text-slate-950 bg-gradient-to-r from-amber-500 to-[#F5A623] shadow-md text-sm cursor-pointer"
              >
                Request Technical Quotation
              </button>
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-3 px-4 rounded-xl font-semibold text-center text-white bg-[#0A4DA2] hover:bg-[#003C7E] text-sm cursor-pointer"
              >
                Mobilize Engineering Inspection
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}

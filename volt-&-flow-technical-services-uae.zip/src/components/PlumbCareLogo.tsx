import { IMAGES } from '../data/content';

interface PlumbCareLogoProps {
  className?: string;
  variant?: 'full' | 'mark' | 'horizontal' | 'image';
  dark?: boolean;
}

export default function PlumbCareLogo({ className = '', variant = 'horizontal', dark = false }: PlumbCareLogoProps) {
  // Option to render the generated high-res image directly
  if (variant === 'image') {
    return (
      <div className={`relative inline-flex items-center ${className}`}>
        <img
          src={IMAGES.logo}
          alt="PlumbCare UAE - Your Trusted Plumbing Partner"
          className="h-10 w-auto object-contain rounded-lg"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Full Vector SVG matching the uploaded logo exactly
  // Colors: Navy #08377A, Royal Blue #0084D6, Cyan #00A3E0, UAE Flag Red #E4002B, Green #009739, Black #000000
  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Emblem SVG: House + Pipe Wrench + Water Drop + Dubai Skyline + UAE Wave */}
      <svg
        viewBox="0 0 160 160"
        className="w-11 h-11 shrink-0 drop-shadow-xs"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* House Gable Roof */}
        <path
          d="M20 72L80 18L140 72"
          stroke="#0084D6"
          strokeWidth="10"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* 4-Pane Window in Gable */}
        <rect x="70" y="32" width="8" height="8" rx="1" fill="#0084D6" />
        <rect x="82" y="32" width="8" height="8" rx="1" fill="#0084D6" />
        <rect x="70" y="44" width="8" height="8" rx="1" fill="#0084D6" />
        <rect x="82" y="44" width="8" height="8" rx="1" fill="#0084D6" />

        {/* Dubai Skyline Silhouette (Right side) */}
        {/* Burj Khalifa */}
        <path
          d="M108 85V42L110 38V22H112V38L114 42V85"
          fill="#08377A"
        />
        {/* Modern Tower */}
        <path
          d="M117 85V54L123 58V85"
          fill="#08377A"
        />
        {/* Burj Al Arab Curved Sail Silhouette */}
        <path
          d="M127 85V70C127 70 135 71 138 78C140 82 140 85 140 85H127Z"
          fill="#08377A"
        />
        <line x1="126" y1="67" x2="126" y2="85" stroke="#08377A" strokeWidth="2" />

        {/* Water Wave Swooshes under Skyline */}
        <path
          d="M102 92C116 88 132 88 145 96C138 98 126 98 116 97Z"
          fill="#00A3E0"
        />
        <path
          d="M96 97C114 93 132 94 148 103C138 105 122 104 110 102Z"
          fill="#0084D6"
        />

        {/* Blue Pipe Forming Wrench */}
        {/* Vertical Left Pipe */}
        <path
          d="M48 68V106C48 114 54 120 62 120H112"
          stroke="#08377A"
          strokeWidth="11"
          strokeLinecap="round"
        />
        {/* Pipe Flange Connector Rings */}
        <rect x="42" y="78" width="12" height="6" rx="2" fill="#08377A" />
        <rect x="74" y="114" width="6" height="12" rx="2" fill="#08377A" />

        {/* Wrench Jaw (Right End of Pipe) */}
        <path
          d="M110 114H124C126 114 128 112 129 110L135 110C134 116 130 120 125 120C130 120 134 124 135 130L129 130C128 128 126 126 124 126H110V114Z"
          fill="#08377A"
        />

        {/* Top/Right Loop Connection */}
        <path
          d="M48 68H100C110 68 118 76 118 86"
          stroke="#08377A"
          strokeWidth="11"
          strokeLinecap="round"
        />

        {/* Water Droplet Inside Loop */}
        <path
          d="M80 62C80 62 65 82 65 94C65 102 71.7 108 80 108C88.3 108 95 102 95 94C95 82 80 62 80 62Z"
          fill="url(#dropletGradient)"
        />
        {/* Droplet Highlight Reflection */}
        <path
          d="M72 90C72 84 75 78 77 75C76 79 76 86 77 91C78 96 76 99 74 100C72.8 97 72 93.8 72 90Z"
          fill="white"
          opacity="0.65"
        />

        {/* Gradients */}
        <defs>
          <linearGradient id="dropletGradient" x1="80" y1="62" x2="80" y2="108" gradientUnits="userSpaceOnUse">
            <stop stopColor="#00A3E0" />
            <stop offset="1" stopColor="#0072CE" />
          </linearGradient>
        </defs>
      </svg>

      {/* Typography: PlumbCare UAE + Tagline */}
      <div className="flex flex-col">
        <div className="flex items-baseline leading-none">
          <span className={`text-2xl font-black tracking-tight ${dark ? 'text-white' : 'text-[#08377A]'}`}>
            Plumb
          </span>
          <span className="text-2xl font-black tracking-tight text-[#0084D6]">
            Care
          </span>
        </div>

        {/* UAE rule with UAE flag ribbon swoosh */}
        <div className="flex items-center gap-1.5 mt-1">
          <span className={`h-[1.5px] w-3 ${dark ? 'bg-white/40' : 'bg-[#08377A]/50'}`} />
          <span className={`text-[12px] font-black tracking-[0.2em] ${dark ? 'text-white' : 'text-[#08377A]'}`}>
            UAE
          </span>
          <span className={`h-[1.5px] w-2 ${dark ? 'bg-white/40' : 'bg-[#08377A]/50'}`} />
          
          {/* UAE Flag Swoosh (Red, Green, White, Black) */}
          <div className="inline-flex items-center h-3 w-5 overflow-hidden rounded-[2px] shadow-2xs ml-0.5">
            <div className="w-1.5 h-full bg-[#E4002B]" />
            <div className="flex flex-col flex-1 h-full">
              <div className="flex-1 bg-[#009739]" />
              <div className="flex-1 bg-white" />
              <div className="flex-1 bg-black" />
            </div>
          </div>
        </div>

        {/* Tagline */}
        <span className={`text-[8.5px] font-bold tracking-[0.14em] uppercase mt-0.5 whitespace-nowrap ${
          dark ? 'text-slate-300' : 'text-[#08377A]/80'
        }`}>
          Your Trusted Plumbing Partner
        </span>
      </div>
    </div>
  );
}

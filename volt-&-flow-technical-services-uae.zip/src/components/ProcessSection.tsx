import { PhoneCall, Search, FileCheck, Award, ArrowRight } from 'lucide-react';
import { PROCESS_STEPS } from '../data/content';

interface ProcessSectionProps {
  onOpenBooking: () => void;
}

export default function ProcessSection({ onOpenBooking }: ProcessSectionProps) {
  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'PhoneCall':
        return <PhoneCall className="w-6 h-6 text-white" />;
      case 'Search':
        return <Search className="w-6 h-6 text-white" />;
      case 'FileCheck':
        return <FileCheck className="w-6 h-6 text-white" />;
      case 'Award':
        return <Award className="w-6 h-6 text-white" />;
      default:
        return <PhoneCall className="w-6 h-6 text-white" />;
    }
  };

  return (
    <section id="process" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Centered Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-50 text-[#0A4DA2] text-xs font-bold uppercase tracking-wider mb-3">
            <span>Structured Operational Protocol</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Our Four-Stage Engineering Engagement Model
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600">
            A systematic, documented methodology designed to provide absolute fiscal predictability, non-destructive diagnostic certainty, and full regulatory compliance.
          </p>
        </div>

        {/* 4 Horizontal Steps Connected by Arrow Lines */}
        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {PROCESS_STEPS.map((item, idx) => (
              <div
                key={item.step}
                className="relative bg-[#F8FAFC] rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-2xs hover:shadow-md hover:border-blue-200 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Top Badge & Numbered Circular Icon */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="relative">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#003C7E] to-[#0A4DA2] flex items-center justify-center shadow-md shadow-blue-900/20">
                        {getStepIcon(item.iconName)}
                      </div>
                      <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center border-2 border-white shadow-2xs">
                        {item.step}
                      </span>
                    </div>

                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 leading-snug">
                    {item.title}
                  </h3>

                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Arrow indicator on desktop between cards */}
                {idx < PROCESS_STEPS.length - 1 && (
                  <div className="hidden lg:block absolute -right-5 top-1/2 -translate-y-1/2 z-20">
                    <div className="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-md flex items-center justify-center text-slate-400">
                      <ArrowRight className="w-5 h-5 text-[#0A4DA2]" />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Callout */}
        <div className="mt-12 text-center">
          <button
            type="button"
            onClick={onOpenBooking}
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl font-bold text-sm bg-slate-900 hover:bg-slate-800 text-white shadow-md transition-all duration-200 active:scale-98 cursor-pointer"
          >
            <span>Initiate Stage 1: Register Engineering Mobilization</span>
            <ArrowRight className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </div>
    </section>
  );
}

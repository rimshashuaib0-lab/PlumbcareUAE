import { useState } from 'react';
import { X, Calculator, Check, ArrowRight, ShieldCheck, Banknote } from 'lucide-react';
import { SERVICES, COMPANY_INFO } from '../data/content';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToBook: (serviceId: string) => void;
}

export default function QuoteModal({ isOpen, onClose, onProceedToBook }: QuoteModalProps) {
  const [selectedServiceId, setSelectedServiceId] = useState(SERVICES[0].id);
  const [propertyType, setPropertyType] = useState<'apartment' | 'villa' | 'commercial'>('villa');
  const [urgency, setUrgency] = useState<'standard' | 'emergency'>('standard');

  if (!isOpen) return null;

  const currentService = SERVICES.find((s) => s.id === selectedServiceId) || SERVICES[0];

  // Calculate realistic estimated price range in AED
  let basePrice = currentService.startingPriceAED;
  if (propertyType === 'villa') basePrice *= 1.35;
  if (propertyType === 'commercial') basePrice *= 1.6;
  if (urgency === 'emergency') basePrice += 50;

  const minPrice = Math.round(basePrice);
  const maxPrice = Math.round(basePrice * 1.4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#003C7E] to-[#0A4DA2] text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold tracking-tight">
                Technical Scope &amp; Tariff Estimator
              </h3>
              <p className="text-xs text-blue-100 mt-0.5">
                PlumbCare UAE · Structured AED Tariff Schedule
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close quote modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 sm:p-7 space-y-6">
          {/* Step 1: Select Service */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              1. Specify Required Engineering Discipline
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SERVICES.map((service) => (
                <button
                  key={service.id}
                  type="button"
                  onClick={() => setSelectedServiceId(service.id)}
                  className={`p-3 rounded-xl text-left border text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                    selectedServiceId === service.id
                      ? 'bg-blue-50 border-[#0A4DA2] text-[#0A4DA2] shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <span className="truncate">{service.title}</span>
                  {selectedServiceId === service.id && (
                    <Check className="w-4 h-4 text-[#0A4DA2] shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Property Type */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              2. Premises Classification
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'apartment', label: 'Luxury Penthouse / Flat' },
                { id: 'villa', label: 'Private Villa / Estate' },
                { id: 'commercial', label: 'Commercial / Hospitality' },
              ].map((prop) => (
                <button
                  key={prop.id}
                  type="button"
                  onClick={() => setPropertyType(prop.id as any)}
                  className={`p-3 rounded-xl text-center border text-xs font-bold transition-all cursor-pointer ${
                    propertyType === prop.id
                      ? 'bg-amber-50 border-amber-500 text-amber-950 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  {prop.label}
                </button>
              ))}
            </div>
          </div>

          {/* Step 3: Urgency */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              3. Deployment Priority
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setUrgency('standard')}
                className={`p-3 rounded-xl text-center border text-xs font-bold transition-all cursor-pointer ${
                  urgency === 'standard'
                    ? 'bg-slate-100 border-slate-700 text-slate-900'
                    : 'bg-white border-slate-200 text-slate-600'
                }`}
              >
                Standard Scheduled Mobilization
              </button>
              <button
                type="button"
                onClick={() => setUrgency('emergency')}
                className={`p-3 rounded-xl text-center border text-xs font-bold transition-all cursor-pointer ${
                  urgency === 'emergency'
                    ? 'bg-red-50 border-red-500 text-red-900'
                    : 'bg-white border-slate-200 text-slate-600'
                }`}
              >
                ⚡ 30-Min Critical Emergency
              </button>
            </div>
          </div>

          {/* Live Estimate Result Banner */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-[#0B1E3D] text-white">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1.5">
                <Banknote className="w-4 h-4" />
                Estimated Baseline Tariff Window
              </span>
              <span className="text-[11px] text-slate-400">VAT Included</span>
            </div>

            <div className="text-3xl sm:text-4xl font-black text-white tabular-nums tracking-tight font-mono">
              AED {minPrice} – AED {maxPrice}
            </div>

            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              *Encompasses preliminary diagnostic analysis, certified engineer deployment, and standard consumables. OEM replacement components (Schneider Electric, ABB, Ariston, Grundfos) are specified on an itemized basis.
            </p>

            <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Initial diagnostic fee (AED 99) is fully absorbed upon work authorization.</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                onProceedToBook(selectedServiceId);
                onClose();
              }}
              className="flex-1 py-3.5 px-5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Lock Tariff &amp; Schedule Inspection</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="py-3.5 px-4 rounded-xl font-semibold text-xs text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

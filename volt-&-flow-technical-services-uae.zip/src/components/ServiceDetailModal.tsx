import { X, CheckCircle2, ArrowRight } from 'lucide-react';
import { ServiceItem } from '../types';
import { COMPANY_INFO } from '../data/content';

interface ServiceDetailModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  onBookService: (serviceId: string) => void;
}

export default function ServiceDetailModal({ service, onClose, onBookService }: ServiceDetailModalProps) {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Top Image Banner */}
        <div className="relative h-64 w-full bg-slate-900">
          <img
            src={service.image}
            alt={service.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-900/60 hover:bg-slate-900 text-white flex items-center justify-center backdrop-blur-sm transition-colors cursor-pointer"
            aria-label="Close specifications"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Title & Badge on Image */}
          <div className="absolute bottom-6 left-6 right-6">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 border border-amber-400/30 px-3 py-1 rounded-full mb-2 inline-block">
              {service.category === 'plumbing' ? 'Hydraulic Engineering Division' : 'Electrical Contracting Division'}
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white">
              {service.title}
            </h3>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Description */}
          <p className="text-base text-slate-700 leading-relaxed">
            {service.fullDescription}
          </p>

          {/* Key Specs Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs">
            <div>
              <span className="text-slate-400 block font-medium">Baseline Tariff:</span>
              <span className="text-base font-extrabold text-[#003C7E] font-mono">
                From AED {service.startingPriceAED}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Typical Operational Window:</span>
              <span className="text-sm font-bold text-slate-800">
                {service.typicalDuration}
              </span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="text-slate-400 block font-medium">Warranty Governance:</span>
              <span className="text-sm font-bold text-emerald-600">
                12-Month Stamped SLA
              </span>
            </div>
          </div>

          {/* Included Technical Scope */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-3">
              Technical Scope of Execution
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {service.features.map((feat, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-600">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Calibrated Instrumentation */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-2">
              Calibrated Diagnostic Instrumentation Utilized
            </h4>
            <div className="flex flex-wrap gap-2">
              {service.equipmentUsed.map((eq, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-100 text-xs font-semibold text-[#0A4DA2]"
                >
                  {eq}
                </span>
              ))}
            </div>
          </div>

          {/* CTA Footer */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-500 text-center sm:text-left">
              Direct emergency dispatch desk:{' '}
              <a href={`tel:${COMPANY_INFO.hotline}`} className="font-bold text-[#0A4DA2] underline">
                {COMPANY_INFO.hotlineDisplay}
              </a>
            </div>

            <button
              type="button"
              onClick={() => {
                onBookService(service.id);
                onClose();
              }}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-md shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Schedule Inspection for This Discipline</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

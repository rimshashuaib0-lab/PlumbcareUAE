import { useState } from 'react';
import { ArrowRight, Search, Waves, Wrench, Flame, Zap, Lightbulb, Clock, Check, Layers } from 'lucide-react';
import { SERVICES } from '../data/content';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
  onOpenBookingWithService: (serviceId: string) => void;
}

export default function ServicesSection({ onSelectService, onOpenBookingWithService }: ServicesSectionProps) {
  const [filter, setFilter] = useState<'all' | 'plumbing' | 'electrical'>('all');

  const filteredServices = SERVICES.filter((service) => {
    if (filter === 'all') return true;
    return service.category === filter;
  });

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Search':
        return <Search className="w-5 h-5 text-white" />;
      case 'Waves':
        return <Waves className="w-5 h-5 text-white" />;
      case 'Wrench':
        return <Wrench className="w-5 h-5 text-white" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-white" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-white" />;
      case 'Lightbulb':
        return <Lightbulb className="w-5 h-5 text-white" />;
      default:
        return <Wrench className="w-5 h-5 text-white" />;
    }
  };

  return (
    <section id="services" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-blue-100 text-[#0A4DA2] text-xs font-bold uppercase tracking-wider mb-3">
            <Layers className="w-3.5 h-3.5" />
            <span>Core Disciplines &amp; Field Capabilities</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Comprehensive Mechanical, Electrical &amp; Plumbing Capabilities
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600">
            Precision engineering solutions executed in strict compliance with Dubai Electricity and Water Authority (DEWA), Dubai Municipality building regulations, and British Standard BS 7671.
          </p>

          {/* Category Filter Tabs */}
          <div className="mt-8 inline-flex items-center p-1.5 bg-slate-200/80 rounded-2xl shadow-inner">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
                filter === 'all'
                  ? 'bg-white text-[#0A4DA2] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Disciplines ({SERVICES.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('plumbing')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
                filter === 'plumbing'
                  ? 'bg-white text-[#0A4DA2] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Hydraulic &amp; Sanitary Engineering
            </button>
            <button
              type="button"
              onClick={() => setFilter('electrical')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
                filter === 'electrical'
                  ? 'bg-white text-[#0A4DA2] shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Electrical &amp; Switchgear Infrastructure
            </button>
          </div>
        </div>

        {/* 3x2 Grid of 6 Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group bg-white rounded-3xl overflow-hidden border border-slate-200/80 shadow-xs hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col"
            >
              {/* Image Container with Overlapping Icon Badge */}
              <div className="relative h-52 w-full overflow-hidden bg-slate-100">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent opacity-70" />

                {/* Overlapping Icon Badge */}
                <div className="absolute -bottom-4 left-6 w-12 h-12 rounded-2xl bg-gradient-to-br from-[#003C7E] to-[#0A4DA2] text-white flex items-center justify-center shadow-lg shadow-blue-950/20 border-2 border-white">
                  {getServiceIcon(service.iconName)}
                </div>

                {/* Emergency Dispatch Tag */}
                {service.emergencyAvailable && (
                  <div className="absolute top-4 right-4 bg-amber-500 text-slate-950 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>24/7 Rapid Protocol</span>
                  </div>
                )}
              </div>

              {/* Card Body */}
              <div className="p-6 pt-7 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                    <span className="uppercase font-bold tracking-wider text-[#0A4DA2]">
                      {service.category === 'plumbing' ? 'Hydraulic Division' : 'Electrical Division'}
                    </span>
                    <span className="font-semibold text-slate-700">Tariff from AED {service.startingPriceAED}</span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#0A4DA2] transition-colors leading-snug">
                    {service.title}
                  </h3>

                  <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                    {service.shortDescription}
                  </p>

                  {/* Micro feature checkmarks */}
                  <ul className="mt-4 space-y-1.5 pt-3 border-t border-slate-100 text-xs text-slate-600">
                    {service.features.slice(0, 2).map((feat, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span className="truncate">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Actions */}
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => onSelectService(service)}
                    className="inline-flex items-center gap-1 text-sm font-bold text-[#0A4DA2] hover:text-[#003C7E] transition-colors group/btn cursor-pointer"
                  >
                    <span>Technical Specs</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                  </button>

                  <button
                    type="button"
                    onClick={() => onOpenBookingWithService(service.id)}
                    className="text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-500 px-3.5 py-1.5 rounded-xl transition-colors shadow-xs cursor-pointer"
                  >
                    Mobilize Service
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

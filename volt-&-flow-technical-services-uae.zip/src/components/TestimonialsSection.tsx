import { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote, ShieldCheck, MapPin } from 'lucide-react';
import { TESTIMONIALS } from '../data/content';

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-slide every 6 seconds unless hovered
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isPaused]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const getAvatarGradient = (idx: number) => {
    const gradients = [
      'from-blue-700 to-[#003C7E]',
      'from-slate-700 to-slate-900',
      'from-blue-900 to-[#0A4DA2]',
      'from-slate-800 to-blue-950',
    ];
    return gradients[idx % gradients.length];
  };

  return (
    <section id="testimonials" className="py-20 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Centered Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider mb-3">
            <span>Client References &amp; Post-Service Audits</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Trusted by Facility Directors and Prime Estate Owners Across the UAE
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600">
            Documented client evaluations from luxury residential communities, commercial high-rises, and private institutional holdings in Dubai and Abu Dhabi.
          </p>
        </div>

        {/* Testimonials Display (Carousel + Grid View) */}
        <div
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* Main 3-Card Responsive Grid with Active Highlight */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {TESTIMONIALS.slice(0, 3).map((item, idx) => (
              <div
                key={item.id}
                className={`rounded-3xl p-7 flex flex-col justify-between border transition-all duration-300 ${
                  currentIndex === idx
                    ? 'bg-blue-50/50 border-[#0A4DA2]/40 shadow-xl shadow-blue-900/5 -translate-y-1'
                    : 'bg-slate-50 border-slate-200/80 shadow-2xs hover:border-slate-300'
                }`}
              >
                <div>
                  {/* Top Quote Icon & 5 Star Rating */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(item.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <Quote className="w-8 h-8 text-[#0A4DA2]/20 shrink-0" />
                  </div>

                  {/* Quote Body */}
                  <p className="text-slate-700 text-sm sm:text-base leading-relaxed italic mb-6">
                    &ldquo;{item.quote}&rdquo;
                  </p>
                </div>

                {/* Author Info */}
                <div className="pt-4 border-t border-slate-200/60 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-11 h-11 rounded-full bg-gradient-to-tr ${getAvatarGradient(
                        idx
                      )} text-white font-bold text-sm flex items-center justify-center shadow-xs shrink-0`}
                    >
                      {item.avatar}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="text-sm font-bold text-slate-900 leading-tight">
                          {item.name}
                        </h4>
                        <span title="Verified Client Record" className="inline-flex items-center">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{item.role}</p>
                      <p className="text-[11px] text-[#0A4DA2] font-semibold flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3" />
                        {item.location}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    {item.date.split(' ')[0]}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Carousel Navigation Controls (Arrows + Dot Indicators) */}
          <div className="mt-10 flex items-center justify-center gap-4">
            <button
              type="button"
              onClick={handlePrev}
              className="w-10 h-10 rounded-full bg-white border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-700 shadow-sm transition-colors cursor-pointer"
              aria-label="Previous Testimonial"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Dot Indicators */}
            <div className="flex items-center gap-2">
              {TESTIMONIALS.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                    currentIndex === idx ? 'w-8 bg-[#0A4DA2]' : 'w-2.5 bg-slate-300'
                  }`}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={handleNext}
              className="w-10 h-10 rounded-full bg-white border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-700 shadow-sm transition-colors cursor-pointer"
              aria-label="Next Testimonial"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Clock, ShieldCheck, UserCheck, Coins, Award, PhoneCall } from 'lucide-react';
import { IMAGES, COMPANY_INFO, TRUST_POINTS } from '../data/content';

interface USPSectionProps {
  onOpenBooking: () => void;
}

export default function USPSection({ onOpenBooking }: USPSectionProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Clock':
        return <Clock className="w-5 h-5 text-amber-400" />;
      case 'FileBadge':
        return <ShieldCheck className="w-5 h-5 text-amber-400" />;
      case 'UserCheck':
        return <UserCheck className="w-5 h-5 text-amber-400" />;
      case 'Coins':
        return <Coins className="w-5 h-5 text-amber-400" />;
      case 'Shield':
        return <Award className="w-5 h-5 text-amber-400" />;
      default:
        return <Award className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <section id="why-us" className="py-20 bg-[#0B1E3D] text-white relative overflow-hidden">
      {/* Background ambient lighting effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Left Column (Copy + 5 Trust Points) */}
          <div className="lg:col-span-7 space-y-7">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/10 border border-white/15 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <span>Institutional Standards &amp; Assurance</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Why Institutional Asset Managers and Private Villa Owners Entrust PlumbCare UAE
            </h2>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Under the demanding thermal and environmental conditions of the Arabian Gulf, electrical switchgear overheating and hydraulic line failure represent significant structural and operational risks. PlumbCare UAE provides engineered permanence through rigorous diagnostic protocols, credentialed engineers, and institutional accountability.
            </p>

            {/* Row of 5 Small Icon+Label Trust Points */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {TRUST_POINTS.map((point, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 hover:bg-white/10 transition-colors flex items-start gap-3.5"
                >
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
                    {getIcon(point.iconName)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">{point.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 leading-snug">{point.description}</p>
                  </div>
                </div>
              ))}

              {/* Instant Call CTA Tile */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0A4DA2] to-[#003C7E] border border-blue-400/30 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wide block">
                    Immediate Engineering Dispatch
                  </span>
                  <a
                    href={`tel:${COMPANY_INFO.hotline}`}
                    className="text-sm font-bold text-white hover:text-amber-300 transition-colors"
                  >
                    {COMPANY_INFO.hotlineDisplay}
                  </a>
                </div>
                <div className="w-9 h-9 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center shrink-0">
                  <PhoneCall className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Structured Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={onOpenBooking}
                className="px-7 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 shadow-lg shadow-amber-500/25 transition-all duration-200 active:scale-98 cursor-pointer"
              >
                Schedule Engineering Consultation &amp; Inspection
              </button>
            </div>
          </div>

          {/* Right Column: Photo of Engineer with Professional Accreditation Badge */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative max-w-sm sm:max-w-md w-full">
              {/* Outer decorative gradient frame */}
              <div className="absolute -inset-2 rounded-3xl bg-gradient-to-br from-amber-400/20 via-blue-500/20 to-transparent blur-md -z-10" />

              {/* Photo */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white/20 aspect-4/3 sm:aspect-auto">
                <img
                  src={IMAGES.uspTechnician}
                  alt="PlumbCare UAE specialized engineering field lead"
                  className="w-full h-full object-cover object-center max-h-[500px]"
                  referrerPolicy="no-referrer"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1E3D]/80 via-transparent to-transparent" />

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-4 left-4 right-4">
                  <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider block">
                    Mobile Diagnostic Workshops
                  </span>
                  <p className="text-sm font-bold text-white">
                    Fully stocked with certified instrumentation and OEM switchgear
                  </p>
                </div>
              </div>

              {/* Professional Engineering Badge Near Photo */}
              <div className="absolute -top-5 -right-3 sm:-right-6 rotate-3 bg-gradient-to-r from-slate-900 to-[#0B1E3D] text-white p-3.5 sm:p-4 rounded-2xl shadow-xl shadow-slate-950/40 border border-white/20 max-w-[230px] transform hover:rotate-0 transition-transform duration-300">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs mb-1">
                  <span>★★★★★</span>
                  <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/30 px-1.5 py-0.5 rounded font-bold">
                    ISO COMPLIANT
                  </span>
                </div>
                <p className="text-xs sm:text-sm font-bold text-white leading-tight">
                  Rated 4.9/5 Across 1,400+ Documented Client Audits
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

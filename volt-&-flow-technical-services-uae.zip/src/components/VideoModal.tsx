import { X, Play, ShieldCheck, CheckCircle2, PhoneCall } from 'lucide-react';
import { IMAGES, COMPANY_INFO } from '../data/content';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBooking: () => void;
}

export default function VideoModal({ isOpen, onClose, onOpenBooking }: VideoModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 rounded-3xl shadow-2xl border border-white/10 overflow-hidden my-8 text-white">
        {/* Top bar with close button */}
        <div className="p-4 px-6 bg-slate-950 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              PlumbCare UAE · Capability Dossier
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close video"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Presentation */}
        <div className="relative aspect-16/9 bg-slate-950 flex items-center justify-center overflow-hidden">
          <img
            src={IMAGES.heroTechnician}
            alt="Field MEP engineering showcase"
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Interactive Play Presentation */}
          <div className="relative z-10 text-center p-6 space-y-4 max-w-lg">
            <div className="w-18 h-18 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center mx-auto shadow-2xl shadow-amber-400/30 hover:scale-105 transition-transform cursor-pointer">
              <Play className="w-8 h-8 fill-slate-950 ml-1" />
            </div>

            <h4 className="text-xl sm:text-2xl font-black text-white">
              Institutional Engineering Infrastructure in Action
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Examine our calibrated diagnostic equipment, DEWA-certified master engineers, and GPS-dispatched mobile workshops mitigating critical MEP failures across Dubai in under 30 minutes.
            </p>
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="p-6 bg-slate-950/90 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <ShieldCheck className="w-4 h-4" /> DEWA Certified Contractor
            </div>
            <span>•</span>
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" /> 1-Year Performance SLA
            </div>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenBooking();
              }}
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-amber-500 to-[#F5A623] hover:from-amber-600 hover:to-[#e09418] text-slate-950 transition-colors cursor-pointer"
            >
              Mobilize Inspection Team
            </button>
            <a
              href={`tel:${COMPANY_INFO.hotline}`}
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl font-bold text-xs bg-white/10 hover:bg-white/20 text-white flex items-center justify-center gap-1.5 transition-colors"
            >
              <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
              <span>Contact Dispatch</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

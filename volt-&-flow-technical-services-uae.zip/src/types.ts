export interface ServiceItem {
  id: string;
  title: string;
  category: 'plumbing' | 'electrical';
  shortDescription: string;
  fullDescription: string;
  image: string;
  iconName: string;
  startingPriceAED: number;
  features: string[];
  equipmentUsed: string[];
  emergencyAvailable: boolean;
  typicalDuration: string;
}

export interface StatItem {
  value: string;
  label: string;
  subtext: string;
  iconName: string;
}

export interface ProcessStep {
  step: number;
  title: string;
  description: string;
  iconName: string;
  badge: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  location: string;
  avatar: string;
  rating: number;
  quote: string;
  serviceUsed: string;
  date: string;
}

export interface BookingFormData {
  fullName: string;
  phone: string;
  email: string;
  serviceId: string;
  emirate: string;
  area: string;
  urgency: 'emergency_30min' | 'today' | 'scheduled';
  preferredDate: string;
  preferredTime: string;
  notes: string;
}
